Redraft 0.1.0

1. Keep this folder somewhere permanent. Chrome loads the extension from it.
2. Open chrome://extensions, turn on Developer mode, click Load unpacked and
   choose the "extension" folder.
3. With Claude Code installed and logged in, run this once in Terminal, using
   the real path of this folder:

     node ~/Downloads/Redraft/bridge/connect.mjs

   Run it again if you move the folder. macOS and Linux only for now.
   Without Claude Code, or on Windows, paste an Anthropic API key in Redraft settings.
