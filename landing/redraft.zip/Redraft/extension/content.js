(() => {
  // src/swarm.js
  var Swarm = class _Swarm {
    static COLORS = ["#67e8f9", "#86efac", "#fdba74", "#fde047", "#a78bfa", "#f9a8d4", "#fca5a5", "#5eead4"];
    // Selection colour, line colour and shape fill are themeable before the first frame.
    static BLUE = "#2f80ed";
    static LINE = "#7dbbff";
    static INK = "#f5f5f4";
    static OUTLINE = "rgba(0,0,0,.45)";
    static RED = "#ef4444";
    static AMBER = "#f59e0b";
    static GREY = "rgba(152,154,148,.72)";
    constructor(canvas, opts = {}) {
      this.cv = canvas;
      this.ctx = canvas.getContext("2d");
      this.opts = { trail: 26, maxLines: 1300, mesh: 96, sketch: true, sketchAlpha: 1, idle: [0, 0.25], ...opts };
      this.reset();
    }
    reset() {
      this.agents = [];
      this.boxes = [];
      this.lines = [];
      this.holes = [];
      this.veil = 0;
      this.veilColor = "9,10,14";
      this.veilGrid = false;
      this.clock = 0;
      this.leaving = false;
    }
    resize() {
      const dpr = Math.min(devicePixelRatio || 1, 2);
      this.dpr = dpr;
      this.cv.width = innerWidth * dpr;
      this.cv.height = innerHeight * dpr;
    }
    /* ---------- agents ---------- */
    spawn(atEdge = true) {
      const n = this.agents.length;
      const a = {
        color: _Swarm.COLORS[n % _Swarm.COLORS.length],
        mode: "arrow",
        x: 0,
        y: 0,
        trail: [],
        fly: null,
        job: null,
        crowd: null,
        rest: rand(0, 0.6),
        group: n % 5,
        angle: rand(-0.3, 0.3),
        radius: rand(70, 150)
      };
      if (atEdge) {
        a.x = rand(0, innerWidth);
        a.y = scrollY + (Math.random() < 0.5 ? -30 : innerHeight + 30);
      }
      this.agents.push(a);
      return a;
    }
    // Circle a point on screen, used while a page is being scanned.
    orbit(cx, cy) {
      for (const a of this.agents) {
        const ang = a.group * 1.257 + a.angle + this.clock * 1.25;
        a.x = cx + Math.cos(ang) * a.radius;
        a.y = scrollY + cy + Math.sin(ang) * a.radius * 0.92;
      }
    }
    nearestFree(x, y) {
      let best = null, d = Infinity;
      for (const a of this.agents) {
        if (a.job || a.crowd) continue;
        const k = Math.abs(a.x - x) + Math.abs(a.y - y);
        if (k < d) {
          d = k;
          best = a;
        }
      }
      return best;
    }
    busy() {
      return this.agents.some((a) => a.job);
    }
    assign(a, job) {
      a.job = job;
      a.crowd = null;
      a.mode = job.mode || "arrow";
      job.t = 0;
      job.started = false;
      const r = job.rect();
      this.flyTo(a, r.x, r.y + (job.fixed ? scrollY : 0), job.fly);
    }
    flyTo(a, x, y, d, straight) {
      const dx = x - a.x, dy = y - a.y, dist = Math.hypot(dx, dy) || 1;
      const bend = straight ? 0 : Math.min(70, dist * 0.18) * (Math.random() < 0.5 ? -1 : 1);
      a.fly = {
        x0: a.x,
        y0: a.y,
        x1: x,
        y1: y,
        t: 0,
        d: d ?? clamp(dist / 1500, 0.1, 0.55),
        cx: (a.x + x) / 2 - dy / dist * bend,
        cy: (a.y + y) / 2 + dx / dist * bend
      };
    }
    begin(a) {
      const job = a.job, r = job.rect();
      job.started = true;
      job.r = r;
      const box = { x: r.x, y: r.y, w: r.w, h: r.h, fixed: job.fixed, alpha: 1, stroke: job.stroke || _Swarm.BLUE, fill: job.fill, handles: job.handles, badge: job.badge, label: job.label };
      if (job.kind === "draw") {
        box.grow = true;
        box.w = box.h = 0;
      }
      if (job.kind === "line") {
        box.line = true;
        box.h = 0;
      }
      if (job.kind === "trace") box.trace = 0;
      job.box = box;
      this.boxes.push(box);
      if (job.spray) this.spray(r, job.fixed, a.color);
      if (job.crowd) {
        this.agents.filter((o) => !o.job && !o.crowd).slice(0, job.crowd).forEach((o, n) => {
          o.crowd = { job, r, a: n / job.crowd * Math.PI * 2 };
          o.mode = "cross";
        });
      }
      job.onStart?.(job, a);
    }
    advance(a, dt) {
      const job = a.job, r = job.r, box = job.box;
      job.t += dt;
      const p = clamp(job.t / job.dur, 0, 1), e = ease(p), sy = job.fixed ? scrollY : 0;
      if (job.kind === "draw") {
        box.w = r.w * e;
        box.h = r.h * e;
        a.x = r.x + box.w;
        a.y = r.y + box.h + sy;
      } else if (job.kind === "line") {
        box.h = r.h * e;
        a.x = r.x;
        a.y = r.y + box.h;
      } else if (job.kind === "trace") {
        box.trace = e;
        const [px, py] = perimeter(r, e);
        a.x = px;
        a.y = py + sy;
      }
      job.onTick?.(p, a, job);
      if (p >= 1) this.finish(a);
    }
    finish(a) {
      const job = a.job;
      a.job = null;
      job.box.trace = void 0;
      job.box.fading = true;
      if (job.hold) job.box.hold = job.hold;
      for (const o of this.agents) if (o.crowd?.job === job) {
        o.crowd = null;
        o.mode = "arrow";
      }
      job.onDone?.(job, a);
    }
    /* ---------- lines ---------- */
    line(x0, y0, x1, y1, o = {}) {
      if (this.lines.length >= this.opts.maxLines) this.lines.shift();
      this.lines.push({ x0, y0, x1, y1, t: 0, d: o.d ?? 0.5, life: o.life ?? 1.6, color: o.color || _Swarm.LINE, alpha: o.alpha ?? 0.4, fixed: o.fixed, keep: o.keep, dash: o.dash, tip: o.tip });
    }
    // Extension lines running from an element's edges towards the viewport edges.
    spray(r, fixed, color) {
      const W = innerWidth, H = innerHeight, top = fixed ? 0 : scrollY;
      const keep = Math.random() < 0.3;
      const o = { color, fixed, d: rand(0.25, 0.55), life: rand(0.7, 1.7), alpha: rand(0.26, 0.5) };
      const lines = [
        [r.x, r.y, 0, r.y],
        [r.x + r.w, r.y, W, r.y],
        [r.x, r.y + r.h, 0, r.y + r.h],
        [r.x + r.w, r.y + r.h, W, r.y + r.h],
        [r.x, r.y, r.x, top],
        [r.x + r.w, r.y, r.x + r.w, top],
        [r.x, r.y + r.h, r.x, top + H],
        [r.x + r.w, r.y + r.h, r.x + r.w, top + H]
      ];
      for (const l of lines) {
        if (Math.random() < 0.62) this.line(...l, o);
        if (keep && Math.random() < 0.5) this.line(...l, { fixed, keep: true, alpha: 0.1, d: 0.6, dash: true });
      }
      this.line(r.x - 12, r.y - 7, r.x + r.w + 12, r.y - 7, { fixed, color, alpha: 0.55, d: 0.3, life: 0.8, tip: true });
    }
    // Idle agents never hover: they keep ruling straight lines across their part of the page.
    sketch(a, arena) {
      if (a.x < arena.x0 || a.x > arena.x1 || a.y < arena.y0 || a.y > arena.y1) {
        this.flyTo(a, rand(arena.x0, arena.x1), rand(arena.y0, arena.y1), rand(0.3, 0.8));
        return;
      }
      const across = Math.random() < 0.5;
      const reach = rand(90, 460) * (Math.random() < 0.5 ? -1 : 1);
      const at = across ? a.x : a.y, lo = across ? arena.x0 : arena.y0, hi = across ? arena.x1 : arena.y1;
      const to = clamp(at + reach > hi || at + reach < lo ? at - reach : at + reach, lo, hi);
      const x1 = across ? to : a.x;
      const y1 = across ? a.y : to;
      const d = rand(0.28, 0.75);
      a.mode = Math.random() < 0.3 ? "cross" : "arrow";
      this.flyTo(a, x1, y1, d, true);
      a.fly.steady = true;
      this.line(a.x, a.y, x1, y1, { color: a.color, d, alpha: rand(0.2, 0.45) * this.opts.sketchAlpha, life: rand(0.8, 2.2), tip: true });
    }
    /* ---------- simulation ---------- */
    step(dt, arena) {
      this.clock += dt;
      for (const a of this.agents) this.move(a, dt, arena);
      for (const l of this.lines) l.t += dt;
      if (this.leaving) for (const l of this.lines) l.keep = false;
      this.lines = this.lines.filter((l) => l.keep || l.t < l.d + l.life);
      this.boxes = this.boxes.filter((b) => {
        if (!b.fading) return true;
        if (b.hold > 0) {
          b.hold -= dt;
          return true;
        }
        b.alpha -= dt / 0.26;
        return b.alpha > 0;
      });
    }
    move(a, dt, arena) {
      if (a.exit) {
        a.exit.delay -= dt;
        if (a.exit.delay <= 0 && !a.gone) {
          this.flyTo(a, a.exit.x, a.exit.y, a.exit.d);
          a.gone = true;
        }
      }
      if (a.fly) {
        const f = a.fly;
        f.t += dt / f.d;
        const u = clamp(f.t, 0, 1), p = f.steady ? u : ease(u), q = 1 - p;
        a.x = q * q * f.x0 + 2 * q * p * f.cx + p * p * f.x1;
        a.y = q * q * f.y0 + 2 * q * p * f.cy + p * p * f.y1;
        if (f.t >= 1) a.fly = null;
      } else if (a.job) {
        if (!a.job.started) this.begin(a);
        this.advance(a, dt);
      } else if (a.crowd) {
        const { r, a: ang } = a.crowd, turn = ang + this.clock * 0.9;
        a.x += (r.x + r.w / 2 + Math.cos(turn) * (r.w / 2 + 16) - a.x) * 0.12;
        a.y += (r.y + r.h / 2 + Math.sin(turn) * (r.h / 2 + 16) - a.y) * 0.12;
      } else if (arena && !a.exit && this.opts.sketch) {
        a.rest -= dt;
        if (a.rest <= 0) {
          a.rest = rand(...this.opts.idle);
          this.sketch(a, arena);
        }
      }
    }
    leave() {
      this.leaving = true;
      for (const a of this.agents) {
        a.crowd = null;
        a.fly = null;
        a.exit = { delay: rand(0, 0.8), d: rand(0.7, 1.1), x: rand(innerWidth * 0.62, innerWidth + 60), y: scrollY + innerHeight + 60 };
      }
    }
    /* ---------- drawing ---------- */
    clear() {
      this.ctx.setTransform(1, 0, 0, 1, 0, 0);
      this.ctx.clearRect(0, 0, this.cv.width, this.cv.height);
    }
    paint(under) {
      const { ctx, dpr } = this, sy = scrollY;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, innerWidth, innerHeight);
      if (this.veil > 0) this.paintVeil(sy);
      under?.(ctx);
      this.paintLines(sy);
      for (const b of this.boxes) this.drawBox(b, sy);
      this.paintMesh(sy);
      for (const a of this.agents) this.drawAgent(a, sy);
      ctx.globalAlpha = 1;
    }
    // A dark sheet over the page; `holes` are the parts the swarm has finished.
    paintVeil(sy) {
      const { ctx } = this;
      ctx.fillStyle = `rgba(${this.veilColor},${this.veil})`;
      ctx.fillRect(0, 0, innerWidth, innerHeight);
      if (this.veilGrid) this.paintGrid(sy);
      ctx.globalCompositeOperation = "destination-out";
      for (const h of this.holes) {
        h.a = Math.min(1, h.a + 0.07);
        ctx.fillStyle = `rgba(0,0,0,${h.a})`;
        ctx.fillRect(h.x, h.fixed ? h.y : h.y - sy, h.w, h.h);
      }
      ctx.globalCompositeOperation = "source-over";
    }
    // Blueprint paper: a fine grid with a heavier line every fifth cell, fixed to the page.
    paintGrid(sy) {
      const { ctx } = this, S = 32, W = innerWidth, H = innerHeight;
      for (const [every, alpha] of [[1, 0.09], [5, 0.2]]) {
        const step = S * every;
        ctx.strokeStyle = `rgba(255,255,255,${alpha * this.veil})`;
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let x = 0; x < W; x += step) {
          ctx.moveTo(x + 0.5, 0);
          ctx.lineTo(x + 0.5, H);
        }
        for (let y = -(sy % step); y < H; y += step) {
          ctx.moveTo(0, y + 0.5);
          ctx.lineTo(W, y + 0.5);
        }
        ctx.stroke();
      }
    }
    paintLines(sy) {
      const { ctx } = this;
      ctx.lineWidth = 1;
      for (const l of this.lines) {
        const p = ease(clamp(l.t / l.d, 0, 1));
        const fade = l.keep ? 1 : clamp((l.d + l.life - l.t) / (l.life * 0.5), 0, 1);
        const off = l.fixed ? 0 : sy;
        const x = l.x0 + (l.x1 - l.x0) * p, y = l.y0 + (l.y1 - l.y0) * p - off;
        ctx.globalAlpha = l.alpha * fade;
        ctx.strokeStyle = l.color;
        ctx.setLineDash(l.dash ? [3, 5] : []);
        ctx.beginPath();
        ctx.moveTo(l.x0 + 0.5, l.y0 - off + 0.5);
        ctx.lineTo(x + 0.5, y + 0.5);
        ctx.stroke();
        if (l.tip) {
          ctx.fillStyle = l.color;
          ctx.fillRect(l.x0 - 1.5, l.y0 - off - 1.5, 3, 3);
          ctx.fillRect(x - 1.5, y - 1.5, 3, 3);
        }
      }
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
    }
    // Thin links between cursors working close together.
    paintMesh(sy) {
      const { ctx, agents } = this, R = this.opts.mesh, R2 = R * R, cells = /* @__PURE__ */ new Map();
      const key = (x, y) => (x + 500) * 4096 + y;
      agents.forEach((a) => {
        const y = a.y - sy;
        if (y < -R || y > innerHeight + R) return;
        const k = key(a.x / R | 0, y / R | 0);
        if (!cells.has(k)) cells.set(k, []);
        cells.get(k).push(a);
      });
      let links = 0;
      ctx.lineWidth = 0.6;
      for (const a of agents) {
        const y = a.y - sy, cx = a.x / R | 0, cy = y / R | 0;
        for (let i = 0; i <= 1; i++) for (let j = -1; j <= 1; j++) {
          for (const b of cells.get(key(cx + i, cy + j)) || []) {
            if (b === a || links > 420) continue;
            if (i === 0 && j <= 0 && b.x <= a.x) continue;
            const d = (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
            if (d > R2) continue;
            ctx.globalAlpha = 0.28 * (1 - d / R2);
            ctx.strokeStyle = a.color;
            ctx.beginPath();
            ctx.moveTo(a.x, y);
            ctx.lineTo(b.x, b.y - sy);
            ctx.stroke();
            links++;
          }
        }
      }
      ctx.globalAlpha = 1;
    }
    drawBox(b, sy) {
      const { ctx } = this, y = b.fixed ? b.y : b.y - sy;
      if (y > innerHeight + 40 || y + b.h < -40) return;
      ctx.globalAlpha = clamp(b.alpha, 0, 1);
      if (b.line) {
        ctx.fillStyle = _Swarm.LINE;
        ctx.fillRect(b.x, y, 1, b.h);
        this.dot(b.x, y);
        this.dot(b.x, y + b.h);
        return;
      }
      if (b.fill) {
        ctx.fillStyle = b.fill;
        ctx.fillRect(b.x, y, b.w, b.h);
      }
      ctx.strokeStyle = b.stroke;
      ctx.lineWidth = 1;
      const X = Math.round(b.x) + 0.5, Y = Math.round(y) + 0.5, W = Math.round(b.w), H = Math.round(b.h);
      if (b.trace != null) {
        const stops = [[X, Y], [X + W, Y], [X + W, Y + H], [X, Y + H], [X, Y]], total = 2 * (W + H) || 1;
        let left = b.trace * total;
        ctx.beginPath();
        ctx.moveTo(X, Y);
        for (let n = 1; n < 5 && left > 0; n++) {
          const [x0, y0] = stops[n - 1], [x1, y1] = stops[n], len = Math.abs(x1 - x0) + Math.abs(y1 - y0);
          const u = Math.min(1, left / (len || 1));
          ctx.lineTo(x0 + (x1 - x0) * u, y0 + (y1 - y0) * u);
          left -= len;
        }
        ctx.stroke();
      } else ctx.strokeRect(X, Y, W, H);
      if (b.handles) {
        this.dot(b.x, y);
        this.dot(b.x + b.w, y);
        this.dot(b.x, y + b.h);
        this.dot(b.x + b.w, y + b.h);
      }
      if (b.badge && b.w > 12) this.tag(b.label || `${Math.round(b.w)} \xD7 ${Math.round(b.h)}`, b.x + b.w / 2, y + b.h + 5);
    }
    dot(x, y) {
      const { ctx } = this;
      ctx.fillStyle = "#fff";
      ctx.fillRect(Math.round(x) - 2, Math.round(y) - 2, 5, 5);
      ctx.strokeStyle = _Swarm.BLUE;
      ctx.lineWidth = 1;
      ctx.strokeRect(Math.round(x) - 1.5, Math.round(y) - 1.5, 4, 4);
    }
    tag(s, cx, y) {
      const { ctx } = this;
      ctx.font = '600 9.5px "JetBrains Mono", ui-monospace, Menlo, monospace';
      const w = ctx.measureText(s).width + 10, x = clamp(cx - w / 2, 2, Math.max(2, innerWidth - w - 2));
      ctx.fillStyle = _Swarm.BLUE;
      ctx.beginPath();
      ctx.roundRect(x, y, w, 15, 3);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.fillText(s, x + 5, y + 11);
    }
    drawAgent(a, sy) {
      const { ctx } = this, x = a.x, y = a.y - sy;
      a.trail.push(x, a.y);
      if (a.trail.length > this.opts.trail * 2) a.trail.splice(0, 2);
      if (y < -60 || y > innerHeight + 60) return;
      const T = a.trail, n = T.length / 2, cut = [0, n / 3 | 0, 2 * n / 3 | 0, n - 1];
      ctx.strokeStyle = a.color;
      ctx.lineCap = "round";
      for (let s = 0; s < 3; s++) {
        if (cut[s + 1] <= cut[s]) continue;
        ctx.globalAlpha = [0.08, 0.2, 0.42][s];
        ctx.lineWidth = [0.6, 1, 1.5][s];
        ctx.beginPath();
        ctx.moveTo(T[cut[s] * 2], T[cut[s] * 2 + 1] - sy);
        for (let i = cut[s] + 1; i <= cut[s + 1]; i++) ctx.lineTo(T[i * 2], T[i * 2 + 1] - sy);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
      if (a.mode === "cross") {
        ctx.fillStyle = a.color;
        ctx.fillRect(x - 6, y - 1, 12, 2.4);
        ctx.fillRect(x - 1, y - 6, 2.4, 12);
      } else if (a.mode === "ibeam") {
        ctx.strokeStyle = _Swarm.INK;
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.moveTo(x, y - 6);
        ctx.lineTo(x, y + 6);
        ctx.moveTo(x - 2.5, y - 7);
        ctx.lineTo(x + 2.5, y - 7);
        ctx.moveTo(x - 2.5, y + 7);
        ctx.lineTo(x + 2.5, y + 7);
        ctx.stroke();
      } else {
        ctx.fillStyle = a.color;
        ctx.strokeStyle = _Swarm.OUTLINE;
        ctx.lineWidth = a.name ? 1.2 : 0.7;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + 3.8, y + 14.5);
        ctx.lineTo(x + 6.4, y + 8.2);
        ctx.lineTo(x + 13, y + 5.6);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      if (a.name) {
        ctx.font = '600 10.5px "Geist Mono", ui-monospace, Menlo, monospace';
        const w = ctx.measureText(a.name).width + 12;
        ctx.fillStyle = a.color;
        ctx.beginPath();
        ctx.roundRect(x + 11, y + 13, w, 18, 5);
        ctx.fill();
        ctx.fillStyle = a.tagInk || "#fff";
        ctx.fillText(a.name, x + 17, y + 26);
      }
    }
  };
  function clamp(v, a, b) {
    return Math.max(a, Math.min(b, v));
  }
  function rand(a, b) {
    return a + Math.random() * (b - a);
  }
  function ease(t) {
    return t * t * (3 - 2 * t);
  }
  function perimeter(r, p) {
    const total = 2 * (r.w + r.h) || 1;
    let d = p * total;
    if (d < r.w) return [r.x + d, r.y];
    d -= r.w;
    if (d < r.h) return [r.x + r.w, r.y + d];
    d -= r.h;
    if (d < r.w) return [r.x + r.w - d, r.y + r.h];
    d -= r.w;
    return [r.x, r.y + r.h - d];
  }
  if (typeof globalThis !== "undefined") globalThis.Swarm = Swarm;

  // src/protocol.js
  function ruleToCss({ selector, css, media }) {
    const body = Object.entries(css).map(([k, v]) => `${k}:${v} !important`).join(";");
    const rule = `${selector}{${body}}`;
    return media ? `@media ${media}{${rule}}` : rule;
  }
  function fontImport(family) {
    const name = family.trim().replace(/ +/g, "+");
    return `@import url("https://fonts.googleapis.com/css2?family=${name}:wght@400;500;600;700&display=swap");`;
  }
  function scrub(text) {
    return text.replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, "[email]").replace(/\b\d(?:[ -]?\d){5,}\b/g, "[number]").replace(/\b[A-Za-z0-9_-]{32,}\b/g, "[token]");
  }

  // src/snapshot.js
  var SKIP = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "LINK", "META", "HEAD", "BR", "WBR"]);
  var OPAQUE = /* @__PURE__ */ new Set(["SVG", "CANVAS", "VIDEO", "IFRAME", "OBJECT", "EMBED", "IMG", "PICTURE", "INPUT", "TEXTAREA", "SELECT"]);
  var MAX_SECTIONS = 12;
  var MAX_NODES = 220;
  var MAX_TEXT = 90;
  var visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.visibility !== "hidden" && s.display !== "none" && +s.opacity > 0.02;
  };
  var hex = (c) => {
    const m = c.match(/[\d.]+/g);
    if (!m) return "";
    if (m.length > 3 && +m[3] === 0) return "-";
    return `#${m.slice(0, 3).map((n) => (+n | 0).toString(16).padStart(2, "0")).join("")}`;
  };
  var label = (el) => {
    const tag = el.tagName.toLowerCase();
    const cls = typeof el.className === "string" ? el.className.trim().split(/\s+/).filter((c) => c.length < 24 && !/\d{3}/.test(c)).slice(0, 2) : [];
    return cls.length ? `${tag}.${cls.join(".")}` : tag;
  };
  var ownText = (el) => {
    let s = "";
    for (const n of el.childNodes) if (n.nodeType === 3) s += n.nodeValue;
    s = scrub(s.replace(/\s+/g, " ").trim());
    return s.length > MAX_TEXT ? `${s.slice(0, MAX_TEXT)}\u2026` : s;
  };
  function findSections(root) {
    let level = [root];
    for (let depth = 0; depth < 7; depth++) {
      const kids = [...level[0].children].filter((e) => !SKIP.has(e.tagName) && visible(e));
      const big = kids.filter((e) => e.getBoundingClientRect().height > 40);
      if (big.length > 1) {
        level = big;
        break;
      }
      if (!big.length) break;
      level = big;
    }
    const limit = innerHeight * 2.2;
    const split = (el, depth) => {
      if (depth > 3 || el.getBoundingClientRect().height <= limit) return [el];
      const kids = [...el.children].filter((e) => !SKIP.has(e.tagName) && visible(e) && e.getBoundingClientRect().height > 40);
      return kids.length > 1 ? kids.flatMap((k) => split(k, depth + 1)) : [el];
    };
    const list = level.flatMap((e) => split(e, 0));
    const out = list.slice(0, MAX_SECTIONS).map((e) => [e]);
    list.slice(MAX_SECTIONS).forEach((e) => out[out.length - 1].push(e));
    return out;
  }
  function describeSection(els, index, byId, twins, nextId) {
    const lines = [], nodes = [];
    const parentStyle = /* @__PURE__ */ new WeakMap();
    const walk = (el, depth, inherited) => {
      if (nodes.length >= MAX_NODES || SKIP.has(el.tagName) || el.id === "redraft" || !visible(el)) return;
      if (el.tagName === "INPUT" && el.type === "password") return;
      const s = getComputedStyle(el), r = el.getBoundingClientRect();
      const id = nextId();
      byId.set(id, el);
      const look = {
        c: hex(s.color),
        bg: hex(s.backgroundColor),
        fs: `${Math.round(parseFloat(s.fontSize))}`,
        fw: s.fontWeight,
        ff: s.fontFamily.split(",")[0].replace(/["']/g, ""),
        r: s.borderTopLeftRadius === "0px" ? "" : s.borderTopLeftRadius
      };
      const changed = Object.entries(look).filter(([k, v]) => v && v !== "-" && inherited[k] !== v).map(([k, v]) => `${k}:${v}`).join(" ");
      const text = el.closest("input,textarea,select") ? "" : ownText(el);
      lines.push(`${"  ".repeat(depth)}${id} ${label(el)}${text ? ` "${text}"` : ""} ${Math.round(r.width)}x${Math.round(r.height)}${changed ? ` ${changed}` : ""}`);
      nodes.push([id, el.tagName.toLowerCase(), Math.round(r.width), Math.round(r.height)]);
      parentStyle.set(el, look);
      if (OPAQUE.has(el.tagName.toUpperCase())) return;
      const seen = /* @__PURE__ */ new Map();
      for (const c of el.children) {
        const key = label(c);
        if (!seen.has(key)) seen.set(key, []);
        seen.get(key).push(c);
      }
      for (const c of el.children) {
        const group = seen.get(label(c));
        if (group.length > 2 && group.indexOf(c) >= 2) continue;
        const before = nodes.length;
        walk(c, depth + 1, look);
        if (group.length > 2 && group[0] === c && nodes.length > before) twins.set(nodes[before][0], group);
      }
      for (const group of seen.values()) {
        if (group.length > 2) lines.push(`${"  ".repeat(depth + 1)}\u2026 ${group.length - 2} more like ${label(group[0])}`);
      }
    };
    els.forEach((el) => walk(el, 0, {}));
    const heading = els.flatMap((e) => [...e.querySelectorAll("h1,h2,h3")]).find((h) => h.textContent.trim());
    return { index, tree: lines.join("\n"), nodes, title: heading ? scrub(heading.textContent.trim()).slice(0, 80) : label(els[0]), els };
  }
  function collectPage() {
    let n = 0;
    const byId = /* @__PURE__ */ new Map(), twins = /* @__PURE__ */ new Map();
    const groups = findSections(document.body);
    const sections = groups.map((els, i) => describeSection(els, i, byId, twins, () => ++n));
    const b = getComputedStyle(document.body);
    const outline = [
      `title: ${scrub(document.title).slice(0, 120)}`,
      `site: ${location.hostname}`,
      `body: bg ${hex(b.backgroundColor)} color ${hex(b.color)} font ${b.fontFamily.split(",")[0]} size ${b.fontSize}`,
      `sections, top to bottom:`,
      ...sections.map((s) => `${s.index + 1}. ${s.title} (${s.nodes.length} nodes)
${s.tree.split("\n").slice(0, 12).join("\n")}`)
    ].join("\n");
    return { outline, sections, byId, twins, nodes: n };
  }
  var wirePage = (page) => ({
    outline: page.outline,
    sections: page.sections.map(({ index, tree, nodes, title }) => ({ index, tree, nodes, title }))
  });

  // src/theme.js
  function parseColor(value) {
    const m = String(value).match(/rgba?\(([^)]+)\)/);
    if (!m) return { r: 0, g: 0, b: 0, a: 0 };
    const [r, g, b, a = 1] = m[1].split(/[ ,/]+/).filter(Boolean).map(parseFloat);
    return { r, g, b, a };
  }
  function saturation({ r, g, b }) {
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    return max === 0 ? 0 : (max - min) / max;
  }
  var lightness = ({ r, g, b }) => (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  var HEADING = /^H[1-6]$/;
  var CONTROL = /^(BUTTON|A|LABEL|SUMMARY)$/;
  var MONO = /mono|courier|consolas|menlo/i;
  function restyle(s, ground, t, viewport) {
    const css = {};
    const bg = parseColor(s.backgroundColor);
    const hasColor = bg.a > 0.08;
    const hasGradient = s.backgroundImage.includes("gradient");
    const hasImage = s.backgroundImage.includes("url(");
    const textClip = s.backgroundClip === "text";
    let nextGround = ground;
    if (textClip) {
      css.background = "none";
      css["-webkit-text-fill-color"] = t.accent;
      css.color = t.accent;
    } else if (s.decor) {
      css.display = "none";
      return { css, ground };
    } else if ((hasColor || hasGradient) && !hasImage) {
      const wide = s.width > viewport.width * 0.8;
      const compact = s.height < 96 && s.width < 460;
      const loud = hasGradient || saturation(bg) > 0.3;
      if (compact && (loud || CONTROL.test(s.tag))) {
        css.background = t.accent;
        nextGround = "accent";
      } else if (wide) {
        css.background = t.bg;
        nextGround = "bg";
      } else {
        css.background = t.surface;
        nextGround = "surface";
      }
    }
    if (s.hasText && !textClip) {
      const ink = parseColor(s.color);
      if (nextGround === "accent") css.color = t.accentText;
      else if (s.tag === "A" && saturation(ink) > 0.3) css.color = t.accent;
      else if (saturation(ink) > 0.45) css.color = t.accent;
      else if (ink.a < 0.75 || Math.abs(lightness(ink) - lightness(s.parentBg || bg)) < 0.42) css.color = t.muted;
      else css.color = t.text;
    }
    if (s.borderWidth > 0 && parseColor(s.borderColor).a > 0.05) {
      css["border-color"] = t.border;
      if (t.borderWidth) css["border-width"] = t.borderWidth;
    }
    if (s.radius > 0) css["border-radius"] = s.radius >= Math.min(s.height / 2, 40) && s.height < 80 ? t.pill : t.radius;
    if (s.boxShadow !== "none") css["box-shadow"] = t.shadow;
    if (HEADING.test(s.tag) || s.fontSize >= 28) {
      css["font-family"] = t.headingFont;
      css["font-weight"] = t.headingWeight;
      css["letter-spacing"] = t.headingSpacing;
      if (t.headingCase !== "none") css["text-transform"] = t.headingCase;
    } else if (MONO.test(s.fontFamily)) {
      css["font-family"] = t.monoFont;
    } else if (s.hasText) {
      css["font-family"] = t.bodyFont;
    }
    return { css, ground: nextGround };
  }
  var SKIP2 = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "LINK", "META", "HEAD", "BR", "WBR", "IMG", "PICTURE", "VIDEO", "CANVAS", "IFRAME", "OBJECT", "EMBED", "SVG", "PATH"]);
  var MAX_ELEMENTS = 15e3;
  function read(el, parentBg) {
    const c = getComputedStyle(el), r = el.getBoundingClientRect();
    const hasText = [...el.childNodes].some((n) => n.nodeType === 3 && n.nodeValue.trim());
    const backgroundImage = c.backgroundImage;
    return {
      tag: el.tagName,
      width: r.width,
      height: r.height,
      top: r.top + scrollY,
      left: r.left,
      hasText,
      parentBg,
      backgroundColor: c.backgroundColor,
      backgroundImage,
      backgroundClip: c.webkitBackgroundClip || c.backgroundClip,
      color: c.color,
      borderWidth: parseFloat(c.borderTopWidth) + parseFloat(c.borderBottomWidth) + parseFloat(c.borderLeftWidth),
      borderColor: c.borderTopColor,
      radius: parseFloat(c.borderTopLeftRadius) || 0,
      boxShadow: c.boxShadow,
      fontSize: parseFloat(c.fontSize),
      fontFamily: c.fontFamily,
      position: c.position,
      decor: !hasText && !el.children.length && c.filter.includes("blur") && (backgroundImage.includes("gradient") || parseColor(c.backgroundColor).a > 0.05)
    };
  }
  function planTheme(root, theme, grounds = /* @__PURE__ */ new WeakMap()) {
    const plan = [], viewport = { width: innerWidth, height: innerHeight };
    const walk = (el, ground, parentBg) => {
      if (plan.length >= MAX_ELEMENTS || SKIP2.has(el.tagName.toUpperCase()) || el.id === "redraft") return;
      if (!el.getClientRects().length) {
        for (const c of el.children) walk(c, ground, parentBg);
        return;
      }
      const s = read(el, parentBg);
      const { css, ground: next } = restyle(s, ground, theme, viewport);
      grounds.set(el, next);
      if (Object.keys(css).length) plan.push({ el, css, top: s.top, left: s.left, width: s.width, height: s.height, fixed: s.position === "fixed" || s.position === "sticky" });
      if (s.decor) return;
      const own = parseColor(s.backgroundColor);
      for (const c of el.children) walk(c, next, own.a > 0.08 ? own : parentBg);
    };
    walk(root, "bg", { r: 255, g: 255, b: 255, a: 1 });
    return plan;
  }
  var themeVars = (t) => ({
    "--nx-bg": t.bg,
    "--nx-surface": t.surface,
    "--nx-text": t.text,
    "--nx-muted": t.muted,
    "--nx-accent": t.accent,
    "--nx-accent-text": t.accentText,
    "--nx-border": t.border,
    "--nx-radius": t.radius,
    "--nx-shadow": t.shadow,
    "--nx-heading": t.headingFont,
    "--nx-body": t.bodyFont
  });

  // src/capture.js
  var hex2 = ({ r, g, b }) => `#${[r, g, b].map((n) => Math.round(n).toString(16).padStart(2, "0")).join("")}`;
  var mix = (a, b, t) => ({ r: a.r + (b.r - a.r) * t, g: a.g + (b.g - a.g) * t, b: a.b + (b.b - a.b) * t, a: 1 });
  var unhex = (s) => ({ r: parseInt(s.slice(1, 3), 16), g: parseInt(s.slice(3, 5), 16), b: parseInt(s.slice(5, 7), 16), a: 1 });
  var Tally = class {
    constructor() {
      this.map = /* @__PURE__ */ new Map();
    }
    add(key, weight = 1) {
      if (key) this.map.set(key, (this.map.get(key) || 0) + weight);
    }
    ranked() {
      return [...this.map.entries()].sort((a, b) => b[1] - a[1]).map((e) => e[0]);
    }
    top() {
      return this.ranked()[0];
    }
  };
  function cleanFont(family) {
    const first = String(family || "").split(",")[0].replace(/["']/g, "").trim();
    const name = first.replace(/^_+/, "").replace(/_(Fallback_)?[0-9a-f]{5,}$/i, "").replace(/_/g, " ").trim();
    return /^[A-Za-z0-9 ]{2,40}$/.test(name) && !/^(system ui|sans serif|serif|monospace|ui sans serif|BlinkMacSystemFont)$/i.test(name.replace(/-/g, " ")) ? name : "";
  }
  var distance = (a, b) => Math.abs(a.r - b.r) + Math.abs(a.g - b.g) + Math.abs(a.b - b.b);
  var chroma = ({ r, g, b }) => Math.max(r, g, b) - Math.min(r, g, b);
  var contrastInk = (c) => lightness(c) > 0.55 ? "#0a0a0a" : "#ffffff";
  function deriveTheme(samples, pageBg) {
    const grounds = new Tally(), inks = new Tally(), accents = new Tally(), borders = new Tally();
    const headFont = new Tally(), bodyFont = new Tally(), monoFont = new Tally(), shadows = new Tally();
    const weights = new Tally(), tracks = new Tally(), cases = new Tally(), widths = new Tally();
    const radii = [], pills = [];
    let accentInk = null;
    for (const s of samples) {
      const bg = parseColor(s.backgroundColor), area = s.width * s.height;
      const gradient = String(s.backgroundImage).match(/rgba?\([^)]+\)/);
      const compact = s.height < 90 && s.width < 460 && s.width > 24;
      const fill = bg.a > 0.5 ? bg : gradient ? parseColor(gradient[0]) : null;
      if (bg.a > 0.5) grounds.add(hex2(bg), area);
      if (fill && compact && saturation(fill) > 0.35) {
        accents.add(hex2(fill), 40);
        if (!accentInk && s.hasText) accentInk = hex2(parseColor(s.color));
      }
      if (s.chars) {
        const ink = parseColor(s.color);
        inks.add(hex2(ink), s.chars);
        if (saturation(ink) > 0.45) accents.add(hex2(ink), s.tag === "A" ? 6 : 1);
        const font = cleanFont(s.fontFamily);
        if (/mono|courier|consolas|menlo/i.test(s.fontFamily)) monoFont.add(font, s.chars);
        else if (/^H[1-3]$/.test(s.tag) || s.fontSize >= 28) {
          headFont.add(font, s.chars * 4);
          weights.add(s.fontWeight, s.chars);
          tracks.add(s.letterSpacing === "normal" ? "" : s.letterSpacing, s.chars);
          cases.add(s.textTransform, s.chars);
        } else bodyFont.add(font, s.chars);
      }
      if (s.borderWidth > 0) {
        const b = parseColor(s.borderColor);
        if (b.a > 0.05) {
          borders.add(hex2(b), area ? Math.sqrt(area) : 1);
          widths.add(`${Math.round(s.borderWidth)}px`, 1);
        }
      }
      if (s.radius > 0) {
        if (compact && s.radius >= s.height / 2) pills.push(s.radius);
        else if (s.width > 80 && s.height > 60) radii.push(Math.min(s.radius, 32));
      }
      if (s.boxShadow && s.boxShadow !== "none" && area > 4e3) shadows.add(s.boxShadow, 1);
    }
    const bgHex = pageBg && parseColor(pageBg).a > 0.5 ? hex2(parseColor(pageBg)) : grounds.top() || "#ffffff";
    const bgColor = unhex(bgHex);
    const surfaceHex = grounds.ranked().find((c) => c !== bgHex && distance(unhex(c), bgColor) > 6 && distance(unhex(c), bgColor) < 240 && saturation(unhex(c)) < 0.5);
    const surface = surfaceHex ? unhex(surfaceHex) : mix(bgColor, lightness(bgColor) > 0.5 ? { r: 0, g: 0, b: 0 } : { r: 255, g: 255, b: 255 }, 0.05);
    const gap = (c) => Math.abs(lightness(unhex(c)) - lightness(bgColor));
    const readable = inks.ranked().filter((c) => gap(c) > 0.3 && chroma(unhex(c)) < 70).slice(0, 4).sort((a, b) => gap(b) - gap(a));
    const textHex = readable[0] || contrastInk(bgColor);
    const text = unhex(textHex);
    const mutedHex = readable.find((c) => distance(unhex(c), text) > 90) || hex2(mix(text, bgColor, 0.4));
    const accentHex = accents.ranked().find((c) => distance(unhex(c), bgColor) > 60) || textHex;
    const accent = unhex(accentHex);
    const onAccent = accentInk && distance(unhex(accentInk), accent) > 120 ? accentInk : contrastInk(accent);
    const median = (list) => {
      const s = [...list].sort((a, b) => a - b);
      return s.length ? s[s.length >> 1] : 0;
    };
    const heavyBorder = parseInt(widths.top(), 10) >= 2;
    const quiet = borders.ranked().slice(0, 4).filter((c) => distance(unhex(c), bgColor) > 10);
    const borderHex = (heavyBorder ? quiet[0] : quiet.sort((a, b) => distance(unhex(a), bgColor) - distance(unhex(b), bgColor))[0]) || hex2(mix(bgColor, text, 0.16));
    return {
      bg: bgHex,
      surface: hex2(surface),
      text: textHex,
      muted: mutedHex,
      accent: accentHex,
      accentText: onAccent,
      border: borderHex,
      ...heavyBorder ? { borderWidth: widths.top() } : {},
      headingFont: headFont.top() || bodyFont.top() || "",
      bodyFont: bodyFont.top() || headFont.top() || "",
      monoFont: monoFont.top() || "",
      headingWeight: Math.round((+weights.top() || 700) / 100) * 100,
      headingSpacing: tracks.top() || "normal",
      headingCase: cases.top() === "uppercase" ? "uppercase" : "none",
      radius: `${median(radii)}px`,
      pill: pills.length ? "999px" : `${median(radii)}px`,
      shadow: shadows.top() || "none"
    };
  }
  var SKIP3 = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "SVG", "PATH", "IMG", "VIDEO", "CANVAS", "IFRAME"]);
  function capturePage() {
    const samples = [];
    const walk = (el) => {
      if (samples.length >= 3e3 || SKIP3.has(el.tagName.toUpperCase()) || el.id === "redraft") return;
      const r = el.getBoundingClientRect();
      if (r.width > 1 && r.height > 1) {
        const c = getComputedStyle(el);
        if (c.visibility !== "hidden" && +c.opacity > 0.1) {
          let chars = 0;
          for (const n of el.childNodes) if (n.nodeType === 3) chars += n.nodeValue.trim().length;
          samples.push({
            tag: el.tagName,
            width: r.width,
            height: r.height,
            chars,
            hasText: chars > 0,
            color: c.color,
            fontSize: parseFloat(c.fontSize),
            fontFamily: c.fontFamily,
            fontWeight: c.fontWeight,
            letterSpacing: c.letterSpacing,
            textTransform: c.textTransform,
            backgroundColor: c.backgroundColor,
            backgroundImage: c.backgroundImage,
            borderWidth: Math.max(parseFloat(c.borderTopWidth), parseFloat(c.borderLeftWidth)),
            borderColor: c.borderTopColor,
            radius: parseFloat(c.borderTopLeftRadius) || 0,
            boxShadow: c.boxShadow
          });
        }
      }
      for (const child of el.children) walk(child);
    };
    walk(document.body);
    const body = getComputedStyle(document.body).backgroundColor, html = getComputedStyle(document.documentElement).backgroundColor;
    return deriveTheme(samples, parseColor(body).a > 0.5 ? body : html);
  }

  // src/content.js
  var Swarm2 = globalThis.Swarm;
  Object.assign(Swarm2, {
    BLUE: "#ffffff",
    LINE: "#ffffff",
    GREY: "rgba(255,255,255,.2)",
    COLORS: ["#ffffff", "#ff5a1f", "#ffd166", "#9fb6ff", "#7dd3fc", "#ffffff", "#ffb38f", "#d6e0ff"]
  });
  var { BLUE, GREY } = Swarm2;
  var clamp2 = (v, a, b) => Math.max(a, Math.min(b, v));
  var HUD_CSS = `
  :host { all: initial; }
  canvas { position: fixed; inset: 0; width: 100vw; height: 100vh; pointer-events: none; z-index: 2147483646; }
  #hud {
    position: fixed; left: 50%; bottom: 16px; transform: translateX(-50%); z-index: 2147483647;
    display: flex; align-items: center; gap: 11px; height: 44px; padding: 0 7px 0 10px; max-width: calc(100vw - 24px);
    border-radius: 13px; background: rgba(10, 15, 36, .94); border: 1px solid rgba(160, 180, 255, .2);
    box-shadow: 0 14px 40px rgba(4, 8, 30, .55), inset 0 1px 0 rgba(255, 255, 255, .06); backdrop-filter: blur(14px);
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, system-ui, sans-serif; color: #f2f4ff; white-space: nowrap; pointer-events: auto;
  }
  #mark { width: 24px; height: 24px; flex: none; display: grid; place-items: center; border-radius: 7px; background: #1237e8; }
  .stat { color: #a3aed6; font-variant-numeric: tabular-nums; } .stat b { color: #fff; font-weight: 650; }
  #status { color: #a3aed6; overflow: hidden; text-overflow: ellipsis; max-width: 280px; }
  #bar { width: 84px; height: 3px; border-radius: 3px; background: rgba(160, 180, 255, .18); overflow: hidden; flex: 0 1 84px; } #bar i { display: block; height: 100%; width: 0; border-radius: 3px; background: #ff5a1f; }
  button { height: 30px; min-width: 30px; padding: 0 11px; border: 0; border-radius: 8px; background: rgba(160, 180, 255, .13); color: #f2f4ff; font: 550 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, system-ui, sans-serif; cursor: pointer; }
  button:hover { background: rgba(160, 180, 255, .24); }
  button.main { background: #1237e8; color: #fff; }
  button.main:hover { background: #3457ff; }
  [hidden] { display: none !important; }
  @media (max-width: 620px) { #bar, #tokens-wrap { display: none; } }
`;
  function createStage() {
    const host = document.createElement("div");
    host.id = "redraft";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${HUD_CSS}</style><canvas></canvas>
    <div id="hud" hidden>
      <span id="mark"><svg width="13" height="13" viewBox="30 16 94 98" aria-hidden="true"><path d="M38 28 L66 106 Q68 112 71 106 L84 74 L115 60 Q121 57 115 54 L44 22 Q35 19 38 28 Z" fill="#fff"/></svg></span>
      <span class="stat"><b id="agents">0</b> agents</span>
      <span class="stat"><b id="ops">0</b> edits</span>
      <span class="stat" id="tokens-wrap"><b id="tokens">0</b> tokens</span>
      <span id="status"></span>
      <span id="bar"><i id="fill"></i></span>
      <button id="speed" title="Change speed">1x</button>
      <button id="stop" title="Stop the agents">Stop</button>
      <button id="undo" class="main" hidden>Undo</button>
      <button id="copy" hidden>Copy CSS</button>
      <button id="close" hidden aria-label="Close">\xD7</button>
    </div>`;
    document.documentElement.append(host);
    const $ = (id) => root.getElementById(id);
    const swarm = new Swarm2(root.querySelector("canvas"), { maxLines: 1500 });
    const paper = () => {
      swarm.veilColor = "18,55,232";
      swarm.veilGrid = true;
    };
    let R = null;
    let touched = null;
    let port = null;
    const setStatus = (s) => {
      $("status").textContent = s;
    };
    function remember(el) {
      if (!touched.styles.has(el)) touched.styles.set(el, el.getAttribute("style"));
    }
    function applyStyle(el, css) {
      remember(el);
      for (const [k, v] of Object.entries(css)) el.style.setProperty(k, v, "important");
      if (touched.exportStyles.length < 4e3) touched.exportStyles.push({ el, css });
    }
    function applyRule(op) {
      const css = ruleToCss(op);
      port.postMessage({ type: "css", css });
      touched.exportRules.push(css);
    }
    function applyFont(family) {
      const css = fontImport(family);
      port.postMessage({ type: "css", css });
      touched.exportRules.unshift(css);
    }
    const rectOf = (el, fixed) => () => {
      const r = el.getBoundingClientRect();
      return { x: r.left, y: r.top + (fixed ? 0 : scrollY), w: r.width, h: r.height };
    };
    const isFixed = (el) => {
      for (let e = el; e && e !== document.body; e = e.parentElement) {
        const p = getComputedStyle(e).position;
        if (p === "fixed" || p === "sticky") return true;
      }
      return false;
    };
    function punch(r, fixed, whole) {
      if (!whole && r.h > innerHeight * 0.55) return;
      if (swarm.holes.length > 900) swarm.holes.shift();
      swarm.holes.push({ x: r.x, y: r.y, w: r.w, h: r.h, a: 0, fixed });
    }
    const firstMatch = (selector) => {
      try {
        return document.querySelector(selector.replace(/:{1,2}(hover|focus|focus-visible|active|before|after)/g, ""));
      } catch {
        return null;
      }
    };
    function startSweep(theme) {
      const grounds = /* @__PURE__ */ new WeakMap();
      const plan = planTheme(document.body, theme, grounds);
      R.theme = theme;
      R.grounds = grounds;
      applyRule({ selector: ":root", css: themeVars(theme) });
      applyRule({ selector: "html, body", css: { background: theme.bg, color: theme.text } });
      const sticky = plan.filter((p) => p.fixed), flow = plan.filter((p) => !p.fixed).sort((a, b) => a.top - b.top);
      const H = document.documentElement.scrollHeight;
      R.sweep = { flow, at: 0, front: 0, H, band: null, duration: clamp2(7 + H / 1500, 9, 22), jobs: 0 };
      for (const p of sticky) {
        applyStyle(p.el, p.css);
        R.played++;
      }
      R.received += plan.length;
      R.focus = 0;
      setStatus(`Restyling ${plan.length} elements`);
      watchForNewNodes();
    }
    function sweepStep(dt) {
      const s = R.sweep, H = innerHeight;
      s.front = Math.min(s.H + 40, s.front + dt * s.H / s.duration);
      let chosen = 0;
      while (s.at < s.flow.length && s.flow[s.at].top < s.front) {
        const p = s.flow[s.at++];
        const area = p.width * p.height;
        if (p.el.isConnected && chosen < 6 && area > 900 && p.top > scrollY - 100 && p.top < scrollY + H) {
          chosen++;
          const rect = rectOf(p.el, false), r = rect(), big = area > 4e4;
          const a = swarm.nearestFree(r.x, r.y) || swarm.spawn(true);
          swarm.assign(a, {
            rect,
            spray: big || Math.random() < 0.3,
            ...big ? { kind: "draw", mode: "cross", dur: 0.5, fill: GREY, handles: true, badge: true } : { kind: "trace", dur: 0.22, stroke: BLUE, badge: Math.random() < 0.3, label: Object.keys(p.css)[0] },
            onDone() {
              if (p.el.isConnected) applyStyle(p.el, p.css);
            }
          });
        } else if (p.el.isConnected) applyStyle(p.el, p.css);
        R.played++;
      }
      if (!s.band) {
        s.band = { x: 0, y: 0, w: innerWidth, h: 0, a: 1, fixed: false };
        swarm.holes.push(s.band);
      }
      s.band.w = innerWidth;
      s.band.h = s.front;
      swarm.line(0, s.front, innerWidth, s.front, { d: 0.01, life: 0.25, alpha: 0.9, color: "#ffffff" });
      R.focus = s.front - innerHeight * 0.25;
      if (s.front >= s.H + 40 && s.at >= s.flow.length) {
        R.sweep = null;
        R.swept = true;
        R.at = 0;
        setStatus("Agents are refining");
      }
    }
    function watchForNewNodes() {
      touched.observer?.disconnect();
      const theme = R.theme, grounds = R.grounds;
      let pending = [];
      const flush = () => {
        const batch = pending;
        pending = [];
        if (!touched) return;
        touched.observer?.disconnect();
        for (const el of batch) {
          if (!el.isConnected) continue;
          for (const p of planTheme(el, theme, grounds)) applyStyle(p.el, p.css);
        }
        touched.observer?.observe(document.body, { childList: true, subtree: true });
      };
      touched.observer = new MutationObserver((records) => {
        for (const r of records) for (const n of r.addedNodes) if (n.nodeType === 1 && n.id !== "redraft") pending.push(n);
        if (pending.length) setTimeout(flush, 120);
      });
      touched.observer.observe(document.body, { childList: true, subtree: true });
    }
    function play({ op }) {
      if (op.op === "font") {
        applyFont(op.family);
        return done();
      }
      if (op.op === "theme") {
        startSweep(op.theme);
        return done();
      }
      const el = op.id != null ? R.page.byId.get(op.id) : firstMatch(op.selector);
      if (op.op !== "rule" && (!el || !el.isConnected)) return done();
      const fixed = el ? isFixed(el) : true;
      const rect = el ? rectOf(el, fixed) : () => ({ x: innerWidth / 2 - 120, y: 80, w: 240, h: 70 });
      const r = rect();
      const big = r.w * r.h > 4e4;
      if (!fixed && R.at >= 0) R.focus = Math.max(R.focusFloor, r.y);
      const job = { rect, fixed, spray: big || Math.random() < 0.35 };
      if (op.op === "text") {
        Object.assign(job, {
          kind: "type",
          mode: "ibeam",
          dur: clamp2(op.text.length / 120, 0.25, 1.4),
          handles: true,
          onStart() {
            remember(el);
            if (!touched.texts.has(el)) touched.texts.set(el, el.innerHTML);
          },
          onTick(p, a2) {
            el.textContent = op.text.slice(0, Math.round(op.text.length * p));
            const c = el.getBoundingClientRect();
            a2.x = c.right;
            a2.y = c.top + scrollY + c.height / 2;
          },
          onDone() {
            el.textContent = op.text;
            finish2(rect());
          }
        });
      } else {
        const label2 = op.op === "rule" ? op.selector : op.op === "hide" ? "hide" : Object.keys(op.css)[0];
        Object.assign(job, big ? { kind: "draw", mode: "cross", dur: clamp2(0.3 + Math.sqrt(r.w * r.h) / 1100, 0.35, 0.9), fill: GREY, handles: true, badge: true, label: `${Math.round(r.w)} \xD7 ${Math.round(r.h)}` } : { kind: "trace", dur: 0.22, stroke: [BLUE, BLUE, "#ffd166", "#ff5a1f"][Math.random() * 4 | 0], badge: Math.random() < 0.5, label: label2 });
        job.onDone = () => {
          if (op.op === "rule") applyRule(op);
          else if (op.op === "hide") applyStyle(el, { display: "none" });
          else {
            applyStyle(el, op.css);
            if (op.same) for (const twin of R.page.twins.get(op.id) || []) applyStyle(twin, op.css);
          }
          finish2(rect());
        };
      }
      const a = swarm.nearestFree(r.x, r.y) || swarm.spawn(true);
      swarm.assign(a, job);
      function finish2(box) {
        if (op.op !== "rule" && !R?.swept) punch(box, fixed);
        done();
      }
    }
    function done() {
      R.applied++;
    }
    function feed(message) {
      if (!R) return;
      const q = R.queues;
      switch (message.type) {
        case "agent":
          if (message.role === "director") setStatus("Director is reading the page");
          if (message.role === "worker") {
            R.workers++;
            R.wantAgents = Math.min(R.maxAgents, R.wantAgents + 34);
          }
          break;
        case "brief":
          setStatus(message.name);
          R.phase = "build";
          break;
        case "op":
          (q.get(message.section) || q.set(message.section, []).get(message.section)).push(message);
          R.received++;
          break;
        case "section-done":
          R.finished.add(message.section);
          break;
        case "usage":
          R.tokens += message.input + message.output;
          break;
        case "warn":
          console.warn("[Swarm]", message.message);
          break;
        case "done":
          R.allDone = true;
          break;
        case "error":
          setStatus(message.message);
          R.failed = true;
          R.allDone = true;
          R.finished = new Set(R.order);
          break;
      }
    }
    function scanQueue() {
      const els = [...R.page.byId.values()].filter((e) => e.getBoundingClientRect().top < innerHeight * 2.5);
      return els.slice(0, 500).sort(() => Math.random() - 0.5);
    }
    function wireframe(r, color) {
      const { x, y, w, h } = r, o = { keep: true, alpha: 0.32, d: 0.3, color };
      swarm.line(x, y, x + w, y, o);
      swarm.line(x + w, y, x + w, y + h, o);
      swarm.line(x + w, y + h, x, y + h, o);
      swarm.line(x, y + h, x, y, o);
    }
    function survey() {
      for (let n = 0; n < 3 && R.scan.length; n++) {
        const a = swarm.nearestFree(innerWidth / 2, scrollY + innerHeight / 2);
        if (!a) return;
        const el = R.scan.pop();
        if (!el.isConnected) continue;
        const fixed = isFixed(el), rect = rectOf(el, fixed), r = rect();
        if (r.w < 6 || r.h < 6 || r.y - (fixed ? 0 : scrollY) > innerHeight * 1.2) continue;
        swarm.assign(a, { rect, fixed, kind: "trace", dur: 0.3, spray: Math.random() < 0.25, onDone: () => {
          if (!fixed) wireframe(r, BLUE);
        } });
      }
    }
    function direct(dt) {
      if (R.sweep) {
        sweepStep(dt);
        return;
      }
      const current = R.order[R.at];
      const q = R.queues.get(current) || [];
      R.credit += dt * clamp2(9 + q.length / 2, 9, 70);
      while (R.credit >= 1 && q.length) {
        R.credit--;
        try {
          play(q.shift());
        } catch (err) {
          console.warn("[Redraft] skipped an edit:", err);
        }
        R.played++;
        if (R.sweep) return;
      }
      R.credit = Math.min(R.credit, 4);
      if (R.waitingFor !== current) {
        R.waitingFor = current;
        R.waitStart = performance.now();
      }
      if (q.length) R.waitStart = performance.now();
      const patient = performance.now() - R.waitStart < 45e3;
      if (!q.length && (R.finished.has(current) || !patient) && !swarm.busy()) {
        const section = R.page.sections[current];
        if (section && !R.swept) {
          for (const el of section.els) if (el.isConnected) {
            const r = el.getBoundingClientRect();
            punch({ x: r.left, y: r.top + scrollY, w: r.width, h: r.height }, false, true);
          }
        }
        R.at++;
        if (R.at < R.order.length) {
          setStatus(`Refining section ${R.at} of ${R.order.length - 1}`);
          const next = R.page.sections[R.order[R.at]];
          const el = next?.els.find((e) => e.isConnected);
          if (el) R.focusFloor = R.focus = el.getBoundingClientRect().top + scrollY;
        }
      }
    }
    function camera(raw, now) {
      if (now < R.userHold) {
        R.cam = scrollY;
        return;
      }
      const max = document.documentElement.scrollHeight - innerHeight;
      const want = clamp2(R.focus - innerHeight * 0.3, 0, Math.max(0, max));
      const step = (want - R.cam) * (1 - Math.exp(-raw * R.speed * 2.2));
      R.cam += clamp2(step, -raw * R.speed * 2600, raw * R.speed * 2600);
      scrollTo({ top: R.cam, behavior: "instant" });
    }
    function frame(now) {
      if (!R) return;
      try {
        tick(now);
      } catch (err) {
        console.warn("[Redraft] recovering from:", err);
        R.failed = true;
        R.allDone = true;
        R.finished = new Set(R.order);
        R.sweep = null;
        R.swept = true;
      }
      if (R) requestAnimationFrame(frame);
    }
    function tick(now) {
      const gap = (now - R.last) / 1e3, raw = Math.min(0.05, gap), dt = raw * R.speed;
      R.last = now;
      if (R.phase !== "exit") {
        R.veilT = R.swept ? Math.max(0, R.veilT - dt / 0.8) : Math.min(1, R.veilT + dt / 0.8);
        swarm.veil = 0.95 * R.veilT;
      }
      if (R.want() > swarm.agents.length) swarm.spawn(true).rest = 0;
      if (R.phase === "scan") {
        R.clock += Math.min(0.5, gap) * R.speed;
        if (R.clock < 1.2) swarm.orbit(innerWidth / 2, innerHeight / 2);
        else {
          R.phase = "survey";
        }
      } else if (R.phase === "survey") {
        survey();
        if (R.queues.size) R.phase = "build";
      } else if (R.phase === "build") {
        direct(dt);
        camera(raw, now);
        if (R.allDone && !R.sweep && R.at >= R.order.length && !swarm.busy()) {
          R.phase = "exit";
          R.exitT = 1.8;
          swarm.leave();
        }
      } else if (R.phase === "exit") {
        swarm.veil = Math.max(0, swarm.veil - dt / 1);
        R.exitT -= dt;
        if (R.exitT <= 0) {
          finish();
          return;
        }
      }
      if (R.allDone && R.failed && R.phase !== "exit") {
        R.phase = "exit";
        R.exitT = 1.8;
        R.swept = true;
        swarm.leave();
      }
      const arena = R.phase !== "exit" && { x0: 0, x1: innerWidth, y0: scrollY + 8, y1: scrollY + innerHeight - 8 };
      swarm.step(dt, arena);
      swarm.paint();
      $("agents").textContent = swarm.agents.length;
      $("ops").textContent = R.played;
      $("tokens").textContent = R.tokens > 999 ? `${(R.tokens / 1e3).toFixed(1)}k` : R.tokens;
      $("fill").style.width = `${R.received ? Math.min(100, R.played / R.received * 100) : 0}%`;
    }
    function finish() {
      const run2 = R;
      R = null;
      swarm.clear();
      swarm.reset();
      if (!run2.failed) setStatus(`Done in ${Math.round((performance.now() - run2.started) / 1e3)}s`);
      $("speed").hidden = $("stop").hidden = true;
      $("undo").hidden = $("copy").hidden = $("close").hidden = false;
      if (performance.now() > run2.userHold) scrollTo({ top: 0, behavior: "smooth" });
    }
    function run(settings) {
      if (R) return;
      if (touched) undo();
      const page = collectPage();
      touched = { styles: /* @__PURE__ */ new Map(), texts: /* @__PURE__ */ new Map(), exportRules: [], exportStyles: [], observer: null };
      port?.disconnect();
      port = chrome.runtime.connect({ name: "swarm" });
      port.onMessage.addListener(feed);
      port.onDisconnect.addListener(() => {
        port = null;
      });
      const ping = setInterval(() => {
        try {
          port ? port.postMessage({ type: "ping" }) : clearInterval(ping);
        } catch {
          clearInterval(ping);
        }
      }, 2e4);
      swarm.reset();
      swarm.resize();
      paper();
      const maxAgents = settings.agents || 240;
      R = {
        page,
        phase: "scan",
        clock: 0,
        last: performance.now(),
        started: performance.now(),
        speed: 1,
        userHold: 0,
        cam: scrollY,
        focus: scrollY + innerHeight * 0.4,
        queues: /* @__PURE__ */ new Map(),
        order: [-1, ...page.sections.map((s) => s.index)],
        at: 0,
        finished: /* @__PURE__ */ new Set(),
        credit: 0,
        received: 0,
        played: 0,
        applied: 0,
        tokens: 0,
        focusFloor: 0,
        swept: false,
        sweep: null,
        workers: 0,
        veilT: 0,
        maxAgents,
        wantAgents: 70,
        want() {
          return this.wantAgents;
        }
      };
      R.scan = scanQueue();
      for (let n = 0; n < 40; n++) swarm.spawn(false);
      $("hud").hidden = false;
      $("speed").hidden = $("stop").hidden = false;
      $("undo").hidden = $("copy").hidden = $("close").hidden = true;
      $("speed").textContent = "1x";
      setStatus("Scanning page\u2026");
      port.postMessage({ type: "start", page: wirePage(page), style: settings.style, preset: settings.preset, savedStyle: settings.savedStyle, allowText: settings.allowText, demo: settings.demo });
      requestAnimationFrame(frame);
    }
    function stop() {
      if (!R) return;
      port?.postMessage({ type: "stop" });
      R.failed = true;
      R.phase = "exit";
      R.exitT = 1.2;
      swarm.leave();
      setStatus("Stopped");
    }
    function undo() {
      if (!touched) return;
      touched.observer?.disconnect();
      for (const [el, style] of touched.styles) {
        if (style == null) el.removeAttribute("style");
        else el.setAttribute("style", style);
      }
      for (const [el, html] of touched.texts) el.innerHTML = html;
      port?.postMessage({ type: "undo" });
      touched = null;
      setStatus("Original page restored");
      $("undo").hidden = $("copy").hidden = true;
    }
    const selectorFor = (el) => {
      if (el.id) return `#${CSS.escape(el.id)}`;
      const path = [];
      for (let e = el; e && e !== document.body && path.length < 6; e = e.parentElement) {
        if (e.id) {
          path.unshift(`#${CSS.escape(e.id)}`);
          break;
        }
        const same = [...e.parentElement?.children || []].filter((c) => c.tagName === e.tagName);
        path.unshift(`${e.tagName.toLowerCase()}${same.length > 1 ? `:nth-of-type(${same.indexOf(e) + 1})` : ""}`);
      }
      return path.join(" > ");
    };
    function exportCss() {
      const rules = touched.exportStyles.map(({ el, css }) => ruleToCss({ selector: selectorFor(el), css }));
      return [`/* Swarm redesign of ${location.hostname} */`, ...touched.exportRules, ...rules].join("\n");
    }
    $("speed").onclick = () => {
      if (!R) return;
      R.speed = R.speed === 1 ? 2 : R.speed === 2 ? 4 : 1;
      $("speed").textContent = `${R.speed}x`;
    };
    $("stop").onclick = stop;
    $("undo").onclick = undo;
    $("close").onclick = () => {
      $("hud").hidden = true;
    };
    $("copy").onclick = async () => {
      if (!touched) return;
      try {
        await navigator.clipboard.writeText(exportCss());
        setStatus("CSS copied");
      } catch {
        setStatus("Copy was blocked on this page");
      }
    };
    const hold = () => {
      if (R) R.userHold = performance.now() + 1800;
    };
    addEventListener("wheel", hold, { passive: true });
    addEventListener("touchmove", hold, { passive: true });
    addEventListener("resize", () => swarm.resize());
    return { run, stop, undo, get running() {
      return !!R;
    }, exportCss };
  }
  if (!window.__redraft) {
    window.__redraft = createStage();
    chrome.runtime.onMessage.addListener((message, _sender, reply) => {
      if (message.type === "run") window.__redraft.run(message.settings);
      if (message.type === "capture") reply({ theme: capturePage(), source: location.hostname });
    });
  }
})();
