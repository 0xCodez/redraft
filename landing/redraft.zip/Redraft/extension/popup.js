// src/protocol.js
var BAD_VALUE = /url\s*\(|image-set\s*\(|image\s*\(|src\s*\(|expression\s*\(|@import|javascript:|<|\\/i;
var FONT = /^[A-Za-z0-9 ]{2,40}$/;
var THEME_COLORS = ["bg", "surface", "text", "muted", "accent", "accentText", "border"];
function cleanTheme(op) {
  const t = {};
  for (const key of THEME_COLORS) {
    const v = op[key];
    if (typeof v !== "string" || !v.trim() || v.length > 60 || BAD_VALUE.test(v)) return null;
    t[key] = v.trim();
  }
  const short = (v, fallback) => typeof v === "string" && v.length <= 80 && !BAD_VALUE.test(v) && !/[;{}]/.test(v) ? v.trim() : fallback;
  const font = (v, generic) => FONT.test(v || "") ? `"${v}", ${generic}` : generic;
  t.headingFont = font(op.headingFont, "system-ui, sans-serif");
  t.bodyFont = font(op.bodyFont, "system-ui, sans-serif");
  t.monoFont = font(op.monoFont, "ui-monospace, monospace");
  t.headingWeight = /^[1-9]00$/.test(String(op.headingWeight)) ? String(op.headingWeight) : "700";
  t.headingSpacing = short(op.headingSpacing, "normal");
  t.headingCase = op.headingCase === "uppercase" ? "uppercase" : "none";
  t.radius = short(op.radius, "8px");
  t.pill = short(op.pill, "999px");
  t.borderWidth = short(op.borderWidth, "");
  t.shadow = short(op.shadow, "none");
  return t;
}
var PRESETS = {
  editorial: { label: "Editorial", prompt: "A confident print-magazine feel: strong serif headlines, generous margins, warm paper tones, one ink accent.", demo: { bg: "#f4efe6", surface: "#fbf8f1", text: "#1b1a17", muted: "#6b665c", accent: "#b4361e", accentText: "#ffffff", border: "#d8d0c2", headingFont: "Fraunces", bodyFont: "Inter", headingWeight: 600, headingSpacing: "-.02em", radius: "2px", pill: "2px", shadow: "none" } },
  terminal: { label: "Terminal", prompt: "A precise developer terminal: near-black, phosphor green accent, monospace everywhere, hairline borders, no shadows.", demo: { bg: "#0a0f0b", surface: "#101812", text: "#d6f5dc", muted: "#7ea487", accent: "#4ade80", accentText: "#06120a", border: "#24412c", headingFont: "JetBrains Mono", bodyFont: "JetBrains Mono", headingWeight: 700, headingSpacing: "-.03em", radius: "0px", pill: "0px", shadow: "none" } },
  glass: { label: "Soft glass", prompt: "Calm frosted glass on a deep blue dusk: translucent panels, soft large radii, airy spacing, a single cool accent.", demo: { bg: "#10182e", surface: "rgba(255,255,255,.08)", text: "#eaf0ff", muted: "#a9b9dc", accent: "#7cc4ff", accentText: "#06223c", border: "rgba(255,255,255,.18)", headingFont: "Sora", bodyFont: "Sora", headingWeight: 600, headingSpacing: "-.03em", radius: "18px", pill: "999px", shadow: "0 18px 50px rgba(3,8,24,.4)" } },
  brutal: { label: "Brutalist", prompt: "Raw neo-brutalism: stark white, thick black borders, hard offset shadows, huge grotesk type, one loud yellow.", demo: { bg: "#ffffff", surface: "#ffffff", text: "#000000", muted: "#222222", accent: "#ffe100", accentText: "#000000", border: "#000000", borderWidth: "3px", headingFont: "Archivo Black", bodyFont: "Inter", headingWeight: 400, headingSpacing: "-.02em", headingCase: "uppercase", radius: "0px", pill: "0px", shadow: "6px 6px 0 #000" } },
  slop: { label: "AI slop", prompt: "Deliberately parody the generic AI landing page: purple-to-blue gradients, glassy cards, glowing buttons, Inter everywhere, oversized rounded corners.", demo: { bg: "#0f0a24", surface: "rgba(168,85,247,.14)", text: "#f2eeff", muted: "#bcb0e6", accent: "#a855f7", accentText: "#ffffff", border: "rgba(168,85,247,.35)", headingFont: "Inter", bodyFont: "Inter", headingWeight: 800, headingSpacing: "-.04em", radius: "24px", pill: "999px", shadow: "0 0 40px rgba(168,85,247,.35)" } }
};

// src/styles.js
var KEY = "styles";
var id = () => `s${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
async function loadStyles() {
  const { [KEY]: list } = await chrome.storage.local.get(KEY);
  return Array.isArray(list) ? list : [];
}
async function write(list) {
  await chrome.storage.local.set({ [KEY]: list });
}
async function saveStyle(style) {
  const list = await loadStyles();
  const clean = sanitizeStyle(style);
  if (!clean) throw new Error("This style is missing colours or a description.");
  const at = list.findIndex((s) => s.id === clean.id);
  if (at >= 0) list[at] = clean;
  else list.unshift(clean);
  await write(list);
  return clean;
}
function sanitizeStyle(raw) {
  if (!raw || typeof raw !== "object") return null;
  const name = String(raw.name || "").trim().slice(0, 40) || "Untitled style";
  const source = String(raw.source || "").slice(0, 80);
  const prompt = typeof raw.prompt === "string" ? raw.prompt.trim().slice(0, 800) : "";
  const theme = raw.theme && cleanTheme(raw.theme) ? raw.theme : null;
  if (!theme && !prompt) return null;
  return { id: typeof raw.id === "string" && raw.id ? raw.id.slice(0, 40) : id(), name, source, prompt, theme };
}

// src/popup.js
var $ = (id2) => document.getElementById(id2);
var SURPRISE = "Surprise me: choose a bold, distinctive direction that suits what this page is about.";
var selected = { kind: "preset", key: "editorial" };
var styles = [];
var captured = null;
var same = (a, b) => a.kind === b.kind && a.key === b.key;
function swatch(t) {
  const card = document.createElement("span");
  card.className = "swatch";
  card.style.background = t.bg;
  card.style.color = t.text;
  const aa = document.createElement("b");
  aa.textContent = "Aa";
  aa.style.fontFamily = `"${t.headingFont}", system-ui, sans-serif`;
  aa.style.fontWeight = t.headingWeight || 700;
  const accent = document.createElement("i");
  accent.style.background = t.accent;
  accent.style.borderRadius = t.pill || "4px";
  const rest = document.createElement("u");
  rest.style.background = t.text;
  rest.style.borderRadius = t.pill || "4px";
  card.append(aa, accent, rest);
  return card;
}
function tile(choice, label, face) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "preset";
  b.setAttribute("aria-pressed", String(same(choice, selected)));
  const name = document.createElement("span");
  name.textContent = label;
  b.append(face, name);
  b.onclick = () => {
    selected = choice;
    draw();
  };
  return b;
}
var icon = (text, cls) => {
  const s = document.createElement("span");
  s.className = `swatch ${cls}`;
  const b = document.createElement("b");
  b.textContent = text;
  s.append(b);
  return s;
};
function draw() {
  const mine = $("mine"), presets = $("presets");
  mine.replaceChildren();
  presets.replaceChildren();
  const add = document.createElement("button");
  add.type = "button";
  add.className = "preset";
  add.innerHTML = '<span class="swatch add"><b>+</b></span><span>New style</span>';
  add.onclick = () => show("create");
  mine.append(add);
  for (const s of styles) mine.append(tile({ kind: "style", key: s.id }, s.name, s.theme ? swatch(s.theme) : icon("\u201D", "words")));
  for (const [key, p] of Object.entries(PRESETS)) presets.append(tile({ kind: "preset", key }, p.label, swatch(p.demo)));
  presets.append(tile({ kind: "surprise", key: "surprise" }, "Surprise me", icon("?", "surprise")));
  const style = currentStyle();
  $("style").placeholder = style?.theme ? "Optional notes for the agents" : "Swiss poster, lots of air, one red accent";
}
var currentStyle = () => selected.kind === "style" ? styles.find((s) => s.id === selected.key) : null;
function show(view) {
  $("home").hidden = view !== "home";
  $("create").hidden = view !== "create";
  $("captured").hidden = true;
  captured = null;
  $("create-msg").textContent = "";
}
async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
  return tab;
}
async function finishSave(style) {
  const saved = await saveStyle(style);
  styles = await loadStyles();
  selected = { kind: "style", key: saved.id };
  show("home");
  draw();
}
$("copy-page").onclick = async () => {
  try {
    const tab = await activeTab();
    const { theme, source } = await chrome.tabs.sendMessage(tab.id, { type: "capture" });
    captured = { theme, source };
    const row = $("captured-swatch");
    row.replaceChildren(swatch(theme));
    $("captured-colors").replaceChildren(...["bg", "surface", "text", "accent", "border"].map((k) => {
      const dot = document.createElement("i");
      dot.style.background = theme[k];
      dot.title = `${k}: ${theme[k]}`;
      return dot;
    }));
    $("captured-fonts").textContent = [theme.headingFont, theme.bodyFont].filter(Boolean).filter((f, i, a) => a.indexOf(f) === i).join(" + ") || "System fonts";
    $("captured-name").value = source.replace(/^www\./, "");
    $("captured").hidden = false;
  } catch (err) {
    $("create-msg").textContent = `This page can't be read: ${err.message}`;
  }
};
$("save-captured").onclick = () => finishSave({ name: $("captured-name").value, source: captured.source, theme: captured.theme });
$("save-words").onclick = () => {
  const prompt = $("words").value.trim();
  if (!prompt) {
    $("create-msg").textContent = "Describe the style first.";
    return;
  }
  finishSave({ name: $("words-name").value || prompt.slice(0, 24), prompt });
};
$("by-hand").onclick = () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("options.html#new") });
};
$("back").onclick = () => show("home");
$("settings").onclick = () => chrome.runtime.openOptionsPage();
async function launch(demo) {
  const { apiKey, connection } = await chrome.storage.local.get(["apiKey", "connection"]);
  if (!demo && connection === "api" && !apiKey) {
    $("msg").textContent = "Add your Anthropic API key in settings first, or try the demo.";
    chrome.runtime.openOptionsPage();
    return;
  }
  const saved = currentStyle();
  const notes = $("style").value.trim();
  const preset = selected.kind === "preset" ? PRESETS[selected.key] : null;
  const style = notes || saved?.prompt || preset?.prompt || (saved ? `Keep to the saved style "${saved.name}".` : SURPRISE);
  try {
    const tab = await activeTab();
    const { agents } = await chrome.storage.local.get("agents");
    await chrome.tabs.sendMessage(tab.id, {
      type: "run",
      settings: {
        style,
        preset: selected.key,
        allowText: $("copy").checked,
        demo,
        agents,
        savedStyle: saved?.theme ? { name: saved.name, prompt: notes || saved.prompt, theme: saved.theme } : void 0
      }
    });
    window.close();
  } catch (err) {
    $("msg").textContent = `This page can't be redesigned: ${err.message}`;
  }
}
$("go").onclick = () => launch(false);
$("demo").onclick = () => launch(true);
(async () => {
  styles = await loadStyles();
  if (styles.length) selected = { kind: "style", key: styles[0].id };
  draw();
  const { connection = "claude-code", apiKey } = await chrome.storage.local.get(["connection", "apiKey"]);
  const status = $("status");
  if (connection === "api") {
    status.dataset.state = apiKey ? "ok" : "warn";
    status.textContent = apiKey ? "Using your API key" : "Add an API key in settings";
    return;
  }
  const result = await chrome.runtime.sendMessage({ type: "check-bridge" }).catch(() => ({ ok: false }));
  status.dataset.state = result.ok ? "ok" : "warn";
  status.textContent = result.ok ? "Claude Code connected" : "Claude Code not connected";
})();
